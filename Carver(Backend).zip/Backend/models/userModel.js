const mongoose = require('mongoose')


const userSchema = new mongoose.Schema({


    fullName:{
        type:String,
        required:true,
        minlength:7,
        maxlength:20,
        trim:true
    },
    email:{
        type:String,
        
    
    },
    
    password:{
        type:String,
        
    },
  //  _roleId:{ type: mongoose.Schema.Types.ObjectId, ref: 'roles'},
   role:{
       type:String,
       enum : ['Recruiter','Learner', 'Sme'] ,
   }
},{
    timestamps: true
})



module.exports = mongoose.model('Users',userSchema);
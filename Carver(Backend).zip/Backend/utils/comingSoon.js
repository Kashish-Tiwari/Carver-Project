var path = require('path');
var ejs = require('ejs');


const comingSoon = async()=>{
    let filePath =  path.join(__dirname,'../Backend/views/comingSoon.js');
    const htmlFile = await ejs.renderFile(filePath);
    console.log(htmlFile);
    return htmlFile;
}



module.exports = comingSoon;
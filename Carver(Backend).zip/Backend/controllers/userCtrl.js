const Users= require('../models/userModel');
//const roles = require('../models/roleModel');
//const encodePassword = require('../utils/encrypt');
const JWT = require('jsonwebtoken');
const bcrypt = require('bcrypt');
var ejs = require('ejs');







const userCtrl = {
 //RegisterUser
 registerUser:async(req,res) =>{
try{
  const { fullName,email,password}= req.body;
   console.log(req.body)
  if(!fullName||!email||!password){
      return res.json({
          success:false,
          message:"Please enter all the fields",
          status:400
      })
  }else{
     const findUser = await Users.findOne({email:email});
      console.log(findUser);
      if(findUser){
        return res.json({
           success:false,
            message:"User already exists",
            status:400  
        })}else{
            const hashedPassword= await bcrypt.hash(password,10);
            console.log(hashedPassword);
           let newUser = new Users({
              fullName:fullName,
              email:email,
              password:hashedPassword
          })
          console.log(newUser);
          await Users.create(newUser)
          const token =  signToken(Users._id);
          console.log(token);
          res.cookie('auth_token',token,{
              httpOnly:true
          });
          return res.json({
              success:true,
              message:"Registered Successfully.",
              status:200,
              token:token
          })
        }
      }
 }
catch(err){
    console.log(err);
}

},
//Login User
loginUser:async(req,res)=>{
   try{
      const {email,password} = req.body;
      if(!email||!password){
          return res.json({
              success:false,
              status:400,
              message:"please enter all the fields"
            })
      }else{
        const user = await Users.findOne({email:email})
        if(!user){
           
            const filepath =path.join(__dirname,'../Backend/views/comingSoon.ejs');
            console.log(filepath);
            await ejs.renderFile(filepath);
        }else{
            const isMatch = await bcrypt.compare(password,user.password);
           console.log(isMatch);
           if(!isMatch){
            return res.json({
                success:false,
                status:400,
                message:"your password or email is incorrect"
              })
           }else{
            const token = JWT.sign({id:user._id},process.env.JWT_SECRET,{expiresIn:"1d"});
            console.log(token);
            return res.json({
                success:true,
                status:200,
                message:"successfully logged in",
                token:token
              })
           }
        }
      }
   }catch(err){

   }
},
//LogOut User
logOut:async(req,res)=>{
    res.clearCookie('auth_token');
    return res.json({
        success:true,
        message:"logout Sucessfully",
        status:200,
    })
},
//changePassword
changePassword:async(req,res)=>{
try{
    let currentUser = req.findUser;
console.log(currentUser,"currentUser");
if(!currentUser){
   return res.json({
       success:false,
       message:"unAuthorized Access",
       status:400
   })
}else{
  const {currentPassword,newPassword,confirmPassword} = req.body;
  const isMatch = await bcrypt.compare(currentPassword,currentUser.password);
  console.log(isMatch);
  if(!isMatch){
    return res.json({
        success:false,
        message:"your current password is incorrect",
        status:400
    })  
  }
  else{
      if(newPassword === confirmPassword){
          hashPassword = await bcrypt.hash(confirmPassword,10);
          console.log(hashPassword);
          let updateUser = await Users.updateOne({_id:currentUser._id},{$set:{password:hashPassword}});
          console.log(updateUser);
          return res.json({
              success:true,
              message:"password changed successfully",
              status:400
          })
      }
      else{
        return res.json({
            success:true,
            message:"newpassword confirm password doesn't match",
            status:400
        }) 
      }
  }
}

}catch(err){
    console.log(err);
}
},
//dumm function
dummy:async(req,res)=>{
const {fullName,email,role}= req.body;
console.log(req.body);
const user = new Users({
    fullName:fullName,
    email:email,
    role:role
})
const createUser = await Users.create(user)
console.log(createUser,"createUser");
if(createUser){
    return res.json({
        success:true,
        message:"sucess"
    })
}else{
    return res.json({
        success:false
    })
}

}


















}
module.exports = userCtrl;
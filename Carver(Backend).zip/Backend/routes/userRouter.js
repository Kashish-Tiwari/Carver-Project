const router = require('express').Router();
const userCtrl = require('../controllers/userCtrl');
const { isAuth } = require('../middleware/auth');

//Register User 
router.post('/signUp',userCtrl.registerUser);
//login User
router.post('/login',userCtrl.loginUser)
//logout User
router.get('/logOut',userCtrl.logOut);
//changePassword
router.put('/changePassword',isAuth,userCtrl.changePassword)
//dummy function
router.post('/dummy',userCtrl.dummy);


module.exports = router;
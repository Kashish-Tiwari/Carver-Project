require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const app = express();
const db = require('./database/database');
const useRouter = require('./routes/userRouter')
 


app.set('view engine','pug')
app.use(express.json());
app.use(cookieParser());
app.use(cors());

db();


app.use('/api',useRouter)


//sever set-up
const port = process.env.PORT;
app.listen(port,()=>{
console.log(`Server is running on ${port}`);
});

